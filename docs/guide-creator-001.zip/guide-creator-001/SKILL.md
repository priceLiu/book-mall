---
name: guide-creator-001
description: 使用指南创建 001 —— 将产品/功能源文档转化为口语化的「用户使用指南」并发布到飞书知识库。This skill should be used when the user asks to "查某文档、按标准写使用指南、上传飞书", or wants to turn internal docs into end-user guides with flowcharts and publish them to a Feishu wiki. Covers doc discovery, colloquial guide writing (step-by-step + mermaid flowchart), local flowchart rendering, and Feishu upload via lark-cli — with the target sub-node chosen by the user each run.
---

# 使用指南创建 001

## Overview

把任意内部/源文档整理成**面向最终用户的口语化使用指南**，并一键发布到飞书知识库。
标准产出 = 口语化分步说明（点哪里 / 传什么 / 会出什么）+ 一张内嵌的 mermaid 流程图。
本 skill 封装了从「查源文档 → 写指南 → 渲染流程图 → 上传飞书」的完整可复用流程，并规避了 lark-cli 在 macOS 沙箱下的鉴权坑。

**核心约束：每一篇指南最终挂到飞书哪个子节点，必须由用户选择，禁止写死。** 详见步骤 5。

## 适用触发

- 用户说「查 XXX 文档，写使用指南」「把这几篇整理成用户向指南，上传飞书」
- 用户给一批源文档（或文件名关键词），要求产出统一风格的用户指南
- 需要批量把 mermaid 流程图渲染成图片并内嵌进飞书文档

## 前置条件

- 已安装 `lark-cli`（`/Users/vic.liu/.npm-global/bin/lark-cli`，v1.0.97）。
- 运行任何涉及用户目录 / 外网的 Bash 必须加 `dangerouslyDisableSandbox=true`（沙箱会拦截飞书 token 写入与外网渲染）。
- 已装 managed python venv（`/Users/vic.liu/.workbuddy/binaries/python/envs/default`，含 `cryptography`）用于解密 token。
- 标准指南风格参考 `assets/guide-template.md`；鉴权与命令细节见 `references/feishu-auth.md`、`references/feishu-commands.md`。

## 标准指南风格（写之前先对齐）

每篇指南必须包含：

1. **开头一段**：用一句话说清这个工具/功能「是干什么的、适合谁、能产出什么」。
2. **前置准备**：用到的入口、账号、素材（如有）。
3. **操作步骤**：用「第一步 / 第二步 …」的口语化叙述，每步写清「点哪里、传什么、会出什么」。禁止堆术语，写用户能照做的动作。
4. **一张流程图**：用 ```` ```mermaid ```` 画主流程（见模板），这是后续渲染成图片内嵌的依据。
5. **小贴士 / 常见坑**：2–4 条实用提醒。

标题写法规律：`<主题>·使用指南`（如「种草视频·使用指南」）。

## Workflow

### Step 1 — 查源文档

- 用 Glob 按用户给的关键词/文件名定位源文档（如 `**/*卡点跳舞*`、`**/*运镜*`）。
- 用 Read 通读每篇，提取：功能定位、操作入口、分步流程、注意事项。
- 若找不到或文档缺失，**停下来问用户**要查的文档名/路径，不要臆造。

### Step 2 — 写本地指南

- 在用户文档目录（通常是 `/Users/vic.liu/Documents/doing/private_website/docs/`）下，按 `assets/guide-template.md` 写 `<主题>-使用指南.md`。
- 每篇含一个 ```` ```mermaid ```` 流程图块（放在「流程图」标题下），只要一张主图即可。
- 写完向用户确认风格/内容是否 OK；如需调整再改。

### Step 3 — 渲染流程图 + 生成飞书版 md

对每篇指南，执行 `scripts/render_flowcharts.py`：

```bash
/Users/vic.liu/.workbuddy/binaries/python/versions/3.13.12/bin/python3 \
  <skill>/scripts/render_flowcharts.py \
  --outdir /Users/vic.liu/Documents/doing/private_website/docs/_fb \
  "<主题>-使用指南.md:<key>"
```

- 脚本会：提取 mermaid → 存 `<key>.mmd` → 调 kroki.io 渲染 PNG（带 3 次重试）→ 复制 PNG 到 `--outdir` → 生成 `<key>.md`（把 mermaid 块整段替换为 `![流程图](@./<key>.png)`）。
- kroki 偶发 500/超时：`render_flowcharts.py` 已内置重试；仍失败时对复杂图用 mermaid.ink 兜底（见 `references/feishu-auth.md` 的「流程图兜底」）。
- 渲染必须在 `dangerouslyDisableSandbox=true` 下跑（否则沙箱出口 IP 被 Cloudflare 拦 403）。
- 关键：**markdown 里用 `![流程图](@./<key>.png)` 引用本地图片**，飞书会在引用位置内嵌图片（优于 `docs +media-insert` 只能堆到末尾）。

### Step 4 — 确保飞书鉴权有效

- 读 `/tmp/usertoken.txt`；若文件不存在或已过期（约 12h），重新走设备流：
  1. `lark-cli auth login > /tmp/auth_login.log 2>&1 &`（后台，需 `dangerouslyDisableSandbox=true`）。
  2. 从 `/tmp/auth_login.log` 取授权链接/授权码，用 `lark-cli auth qrcode "<url>" --output /tmp/auth_qr.png` 生成二维码，**present 给用户并请其扫码授权**，等用户回复「已授权」。
  3. 授权后 token 残留在 `~/Library/Application Support/lark-cli/*.enc`（沙箱偶尔写 .tmp）。用 `scripts/recover_token.py` 解密并写入 `/tmp/usertoken.txt`。
- 后续所有 lark-cli 命令前置环境变量：
  ```bash
  export LARKSUITE_CLI_USER_ACCESS_TOKEN="$(cat /tmp/usertoken.txt)"
  export LARKSUITE_CLI_APP_ID="cli_aa4bbe32da78dbcf"
  export LARK_CLI_NO_PROXY=1
  ```

### Step 5 — 【必须由用户选择】目标子节点

**这一步绝不能写死。** 在创建文档前，先列出知识库里的候选子节点让用户选：

```bash
lark-cli wiki +node-list --space-id 7692419060717341626 \
  --parent-node-token KL4RwLCgdiQrdoka3bjcy647ntf
```

- 把返回的子节点（名称 + node_token）列给用户，用 AskUserQuestion 让其选择本批指南挂到哪个节点。
- 拿到用户选定的 `PARENT_TOKEN` 后再继续。若用户未明确选择，禁止默认落到某个节点。

### Step 6 — 创建飞书文档（内嵌流程图）

对每篇，在 `--outdir` 目录内（`cd` 进去，图片与 md 同目录）执行：

```bash
cd /Users/vic.liu/Documents/doing/private_website/docs/_fb
export LARKSUITE_CLI_USER_ACCESS_TOKEN="$(cat /tmp/usertoken.txt)"
export LARKSUITE_CLI_APP_ID="cli_aa4bbe32da78dbcf"
export LARK_CLI_NO_PROXY=1
lark-cli docs +create --as user --doc-format markdown \
  --content @./<key>.md --parent-token <PARENT_TOKEN> --title "<主题>·使用指南"
```

- 创建成功后返回 JSON 里含 `data.document.url` 与 `data.document.obj_token`，并应有 `image` block（确认流程图已内嵌）。
- 同批多篇用循环跑；标题务必显式传入（变量展开容易为空导致创建异常）。

### Step 7 — 核对落点 + 去重

**创建后务必核对文档真的落在 Step 5 选的节点下**，因为 `docs +create --parent-token` 偶发把文档误挂到别处：

```bash
lark-cli wiki +node-list --space-id 7692419060717341626 \
  --parent-node-token <PARENT_TOKEN>   # 确认数量增加、标题齐全
```

- 若发现某篇挂错节点（常见于被误挂到「电商工具箱」下的 `电商` 文档节点 `BnYlwMmnNiaM05kogqHcmnZCc`）：用 `wiki +move` 移回用户选定节点：
  ```bash
  lark-cli wiki +move --as user --node-token <误挂的node_token> \
    --target-parent-token <PARENT_TOKEN>
  ```
- 若同名旧文档需替换：先 `lark-cli wiki +node-delete --node-token <旧node_token> --obj-type docx --yes` 删除（异步，删除后二次 list 确认无残留同名词），再新建。

### Step 8 — 汇报

- 列出本批每篇的飞书链接、是否含流程图、挂在哪个节点。
- 提醒用户：token 约 12h 过期，下次再传需重新授权。

## Resources

- `assets/guide-template.md` — 标准用户指南模板（口语化分步 + 流程图占位）。
- `scripts/render_flowcharts.py` — 提取 mermaid → kroki 渲染 PNG → 生成飞书版 md（含重试）。
- `scripts/recover_token.py` — 解密 `~/Library/Application Support/lark-cli/*.enc` 取 user token。
- `references/feishu-auth.md` — device-flow 鉴权、沙箱写文件坑、token 解密原理、流程图兜底方案。
- `references/feishu-commands.md` — 各 lark-cli 命令与知识库节点结构速查。
