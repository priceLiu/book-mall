# 飞书知识库命令速查（lark-cli v1.0.97）

## 知识库节点结构（「智选 AI 能力中台」）

- space_id: `7692419060717341626`
- 根节点: `KL4RwLCgdiQrdoka3bjcy647ntf`
- 电商工具箱: `YM4iwdpf9iVwFnkPiG5cxLnpnEh`
  - 营销（文件夹）: `M9eww2U7diX6bzk32hQcXbKdnSc`  ← 用户指南常规落点
  - 电商（文档节点，误挂高发）: `BnYlwMmnNiaM05kogqHcmnZCc`

> 注意：`docs +create --parent-token` 偶发把文档误挂到「电商」节点而非「营销」文件夹，创建后务必 `wiki +node-list` 核对。

## 列出节点

```bash
lark-cli wiki +node-list --space-id 7692419060717341626 \
  --parent-node-token <node_token>
# 输出 JSON: data.nodes[] = {title, obj_type, obj_token, node_token}
#           data.has_more（分页时注意）
```

## 列出知识库

```bash
lark-cli wiki +space-list
```

## 创建文档（内嵌图片）

```bash
cd <图片与 md 同目录>
lark-cli docs +create --as user --doc-format markdown \
  --content @./<key>.md --parent-token <PARENT_TOKEN> --title "<主题>·使用指南"
# 成功返回 data.document.url / data.document.obj_token，含 image block
```

## 删除旧节点（替换时）

```bash
lark-cli wiki +node-delete --node-token <node_token> --obj-type docx --yes
# 异步；删除后二次 node-list 确认无同名残留
```

## 移动节点（误挂纠正）

```bash
lark-cli wiki +move --as user --node-token <误挂node_token> \
  --target-parent-token <正确PARENT_TOKEN>
```

## 读取文档（校验用）

```bash
lark-cli docs +fetch --doc <obj_token>
```

## 通用环境变量（每次前置）

```bash
export LARKSUITE_CLI_USER_ACCESS_TOKEN="$(cat /tmp/usertoken.txt)"
export LARKSUITE_CLI_APP_ID="cli_aa4bbe32da78dbcf"
export LARK_CLI_NO_PROXY=1
```

所有命令在 Bash 中需 `dangerouslyDisableSandbox=true`（访问用户目录 + 外网）。
