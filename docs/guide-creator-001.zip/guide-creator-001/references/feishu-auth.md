# 飞书鉴权参考（lark-cli，macOS 沙箱坑）

## 1. 为什么鉴权会「卡死 / 报 device_code is invalid」

`lark-cli` 走的是飞书私有代理的设备流（device-flow），不是标准 `/open-apis/authen`。
在 macOS 沙箱下，CLI 无法执行 `rename(.tmp → .enc)` 写入 `~/Library/Application Support/lark-cli/`，
于是**即使飞书服务端已返回 HTTP 200 并授权成功，CLI 也会误报 `device_code is invalid`**。

绕过方法：**不要依赖 CLI 自己存 token。授权成功后手动解密残留文件，把 user token 注入环境变量。**

## 2. 标准流程

```bash
# (a) 后台发起设备流（必须沙箱禁用，否则写文件被拦）
export LARK_CLI_NO_PROXY=1
lark-cli auth login > /tmp/auth_login.log 2>&1 &

# (b) 从日志取授权链接/码，生成二维码给用户扫码
sleep 3; cat /tmp/auth_login.log
lark-cli auth qrcode "<日志里的 verify url>" --output /tmp/auth_qr.png --size 280

# (c) 用户扫码授权后，CLI 退出（沙箱下 exit code 可能非 0，忽略）
# (d) 解密残留 token 文件 → 写入 /tmp/usertoken.txt
/Users/vic.liu/.workbuddy/binaries/python/envs/default/bin/python \
  <skill>/scripts/recover_token.py
```

## 3. token 解密原理

- 主密钥：`~/Library/Application Support/lark-cli/master.key.file`（32 字节）。
- token 文件：`*.enc`（有时是 `.tmp`，沙箱写 .enc 失败时残留）。AES-256-GCM 加密。
- 结构：前 12 字节 = nonce；之后 = ciphertext；末尾 16 字节 = GCM tag（已含在 ciphertext 内，AESGCM 自动校验）。
- 解密：`AESGCM(key).decrypt(nonce, ct, None)` → JSON，取 `accessToken`。
- **必须用装了 `cryptography` 的 managed venv 跑**：`/Users/vic.liu/.workbuddy/binaries/python/envs/default/bin/python`。
  （系统 `openssl`/LibreSSL 不支持 `-aes-256-gcm -tag`，别用。）

## 4. 注入环境变量（每次跑 lark-cli 前都要）

```bash
export LARKSUITE_CLI_USER_ACCESS_TOKEN="$(cat /tmp/usertoken.txt)"
export LARKSUITE_CLI_APP_ID="cli_aa4bbe32da78dbcf"
export LARK_CLI_NO_PROXY=1
```

- user token 有效期约 **12 小时**，过期需重新走 §2 全流程。
- `LARK_CLI_NO_PROXY=1` 用于屏蔽环境里的 HTTPS_PROXY 警告（不影响实际请求）。

## 5. 流程图渲染兜底

kroki.io 对部分复杂图（多路菱形决策 + 汇聚）会偶发 500 / 卡死。处理顺序：

1. 首选 `curl -sS -m 55 -X POST https://kroki.io/mermaid/png --data-binary @x.mmd -o x.png`（沙箱禁用）。
2. 若 kroki 失败，重试 2–3 次。
3. 仍失败 → mermaid.ink 兜底：`https://mermaid.ink/img/<urlsafe-base64(mmd)>`。
   该端点返回 JPEG，用 `sips -s format png x.png --out x.png` 转 PNG。
4. `img` 图若 kroki 卡死，可去掉 `「」`、`/`、空格里的 `+` 等字符再试（有时是特殊字符触发旧版 mermaid 解析死循环）。

> 所有外网渲染都要 `dangerouslyDisableSandbox=true`，否则沙箱出口 IP 被 Cloudflare 拦 403。

## 6. 内嵌图片 vs media-insert

- **内嵌（推荐）**：飞书版 md 里写 `![流程图](@./<key>.png)`，且 `cd` 到图片所在目录再 `docs +create`。
  图片会插在引用位置（文档中部），位置可控。
- `lark-cli docs +media-insert` 只能把图片追加到**文档末尾**，不适合流程图居中展示，仅作补充。
