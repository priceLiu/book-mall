#!/usr/bin/env python3
"""Extract mermaid blocks from guide markdown, render to PNG via kroki.io (with retry),
and produce a Feishu-ready markdown that embeds the image inline.

Usage:
  python3 render_flowcharts.py --outdir <dir> "src1.md:key1" "src2.md:key2" ...

For each "<src>:<key>":
  - reads <src>, extracts the FIRST ```mermaid ... ``` block
  - writes <key>.mmd to /tmp/mmd
  - renders to <key>.png via kroki.io POST (3 retries)
  - on kroki failure, falls back to mermaid.ink (returns JPEG, converted to PNG)
  - copies <key>.png into <outdir>
  - writes <outdir>/<key>.md = src with mermaid block replaced by ![流程图](@./<key>.png)

NOTE: must run with dangerouslyDisableSandbox=true (sandbox egress blocked by Cloudflare 403).
"""
import re, os, sys, subprocess, argparse, base64, shutil

KROKI = "https://kroki.io/mermaid/png"
MMDBASE = "/tmp/mmd"


def render_kroki(mmd_path, png_path):
    for _ in range(3):
        try:
            r = subprocess.run(
                ["curl", "-sS", "-m", "55", "-X", "POST", KROKI,
                 "--data-binary", f"@{mmd_path}", "-o", png_path,
                 "-w", "%{http_code}"],
                capture_output=True, text=True, timeout=90)
            if r.returncode == 0 and r.stdout.strip() == "200" and os.path.getsize(png_path) > 0:
                if "png" in subprocess.run(["file", png_path], capture_output=True,
                                           text=True).stdout.lower():
                    return True
        except Exception:
            pass
    return False


def render_mermaid_ink(mmd_path, png_path):
    mmd = open(mmd_path, encoding="utf-8").read()
    enc = base64.urlsafe_b64encode(mmd.encode()).decode().rstrip("=")
    url = f"https://mermaid.ink/img/{enc}"
    try:
        r = subprocess.run(["curl", "-sS", "-m", "55", url, "-o", png_path,
                            "-w", "%{http_code}"], capture_output=True, text=True, timeout=90)
        if r.returncode == 0 and r.stdout.strip() == "200" and os.path.getsize(png_path) > 0:
            if "png" not in subprocess.run(["file", png_path], capture_output=True,
                                           text=True).stdout.lower():
                subprocess.run(["sips", "-s", "format", "png", png_path,
                                "--out", png_path], capture_output=True)
            return True
    except Exception:
        pass
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", required=True)
    ap.add_argument("pairs", nargs="+", help="src.md:key")
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    os.makedirs(MMDBASE, exist_ok=True)
    for pair in args.pairs:
        src, key = pair.split(":", 1)
        text = open(src, encoding="utf-8").read()
        m = re.search(r"```mermaid\n(.*?)```", text, flags=re.S)
        if not m:
            print(f"SKIP {key}: no mermaid block in {src}")
            continue
        mmd = m.group(1)
        mmd_path = os.path.join(MMDBASE, key + ".mmd")
        png_path = os.path.join(MMDBASE, key + ".png")
        open(mmd_path, "w", encoding="utf-8").write(mmd)
        if not render_kroki(mmd_path, png_path):
            print(f"kroki failed for {key}; trying mermaid.ink fallback")
            if not render_mermaid_ink(mmd_path, png_path):
                print(f"FAIL {key}: both renderers failed")
                continue
        shutil.copy(png_path, os.path.join(args.outdir, key + ".png"))
        feishu_md = re.sub(r"```mermaid\n.*?```", f"![流程图](@./{key}.png)",
                          text, flags=re.S)
        open(os.path.join(args.outdir, key + ".md"), "w", encoding="utf-8").write(feishu_md)
        print(f"OK {key}: png + feishu md -> {args.outdir}")


if __name__ == "__main__":
    main()
