#!/usr/bin/env python3
"""Decrypt the lark-cli token file (AES-256-GCM) and write the access token to /tmp/usertoken.txt.

Tries every *.enc / *.tmp under ~/Library/Application Support/lark-cli/; uses the most
recent one that decrypts and contains an accessToken.

Requires the 'cryptography' package (managed venv):
  /Users/vic.liu/.workbuddy/binaries/python/envs/default/bin/python recover_token.py

Background: macOS sandbox blocks CLI from rename(.tmp -> .enc), so the token often lingers
in a residual file even though the device-flow already succeeded server-side.
"""
import os, glob, json
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

BASE = os.path.expanduser("~/Library/Application Support/lark-cli")
KEY = os.path.join(BASE, "master.key.file")
KEY_BYTES = open(KEY, "rb").read()


def try_decrypt(path):
    data = open(path, "rb").read()
    nonce, ct = data[:12], data[12:]
    try:
        return json.loads(AESGCM(KEY_BYTES).decrypt(nonce, ct, None))
    except Exception:
        return None


def main():
    candidates = sorted(
        glob.glob(os.path.join(BASE, "*.enc")) +
        glob.glob(os.path.join(BASE, "*.tmp")),
        key=os.path.getmtime, reverse=True)
    for p in candidates:
        tok = try_decrypt(p)
        if tok and "accessToken" in tok:
            open("/tmp/usertoken.txt", "w").write(tok["accessToken"])
            print(f"OK token from {os.path.basename(p)} -> /tmp/usertoken.txt")
            print("expiresAt:", tok.get("expiresAt") or tok.get("expireAt"))
            return
    print("FAIL: no decryptable token file found")


if __name__ == "__main__":
    main()
